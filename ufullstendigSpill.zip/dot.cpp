#include "dot.h"

Dot::Dot(TDT4102::Point position, int radius,AnimationWindow& win):position{position},radius{radius},win{win}{}

void Dot::drawDot(){
    win.draw_circle(position, radius, color);
}