#pragma once
#include "std_lib_facilities.h"
#include <Point.h>


class Level{
    private:
        int level;
        // const int windowSize;
        int cellSize;
        int gridWidth;
        TDT4102::Point startPoint;
        TDT4102::Point endPoint;
        vector<vector<int>> grid;

        void uploadLevelTile();
        void uploadStartAndEnd();

    public:
        Level(int level, int gridWidth, int cellSize);
        Level(const Level& lvl);
        vector<vector<int>> getGrid(){return grid;}
        int getLevel(){return level;}
        TDT4102::Point getStartPoint(){return startPoint;}
};