#include "std_lib_facilities.h"
#include "maze.h"

int main() {
    Maze maze{1, 10, 50};
    maze.gameWindow();
    return 0;
}