#include "maze.h"

Maze::Maze(int levelNumber, int gridWidth, int cellSize):
    levelNumber{levelNumber},
    level{levelNumber,gridWidth,cellSize},
    AnimationWindow{50,50,500, 500, "Maze"},
    button{{5,5}, 150, 40, buttonLabel},
    dot{level.getStartPoint(), 17, *this}{
        lvlVector.push_back(Level{1,gridWidth,cellSize});
        lvlVector.push_back(Level{2,gridWidth,cellSize});
        lvlVector.push_back(Level{3,gridWidth,cellSize});
    }

void Maze::gameWindow(){
    xPosition = dot.getPositionX();
    yPosition = dot.getPositionY();

    while(!(this->should_close())) {
        int i_upper = (xPosition+dotRadius)/cellSize;
        int i_lower = (xPosition)/cellSize;
        int j_upper = (yPosition+dotRadius*2)/cellSize;
        int j_lower = (yPosition-dotRadius/2)/cellSize;
        int i = xPosition/cellSize;
        int j = yPosition/cellSize;

        vector<vector<int>> grid = level.getGrid();

        if(this->is_key_down(KeyboardKey::RIGHT)){
            moveRight();
        }

        this->drawLevel();
        dot.drawDot();
        
        if (xPosition >= bounds || yPosition >= bounds){
            if (levelNumber == lvlVector.size()){
                levelNumber = 1;
            }else{
                levelNumber++;
            }
            level = lvlVector.at(levelNumber-1);
            xPosition = level.getStartPoint().x;
            yPosition = level.getStartPoint().y;
        }
        dot.setPositionX(xPosition);
        dot.setPositionY(yPosition);
        this->next_frame();
    }
}

void Maze::drawLevel(){
    vector<vector<int>> grid = level.getGrid();
    for (int i = 0; i < gridWidth; i++){
        for (int j = 0; j < gridWidth; j++){
            if (grid[i][j] == 0){
                this->draw_rectangle({j*cellSize, i*cellSize}, cellSize, cellSize, path);
            } else{
                this->draw_rectangle({j*cellSize, i*cellSize}, cellSize, cellSize, walls);
            }
        }
    }
}

void Maze::moveRight(){
    xPosition = xPosition + 2;
   
}
void Maze::moveLeft(){
    xPosition = xPosition - 2;
}
void Maze::moveUp(){
    yPosition = yPosition - 2;
}
void Maze::moveDown(){
    yPosition = yPosition + 2;
}

void Maze::callbackFunction() {
    lightMode = !lightMode;
    if (lightMode){
        buttonLabel = "Light Mode";
        button.setLabel(buttonLabel);
        walls = TDT4102::Color::light_blue;
        path = TDT4102::Color::white;
        dot.setColor(TDT4102::Color::red);}
    else{
        buttonLabel = "Dark Mode";
        button.setLabel(buttonLabel);
        walls = TDT4102::Color::black;
        path = TDT4102::Color::gray;
        dot.setColor(TDT4102::Color::white);
    }
}