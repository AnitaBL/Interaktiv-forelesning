#pragma once
#include "std_lib_facilities.h"
#include <Point.h>
#include "level.h"
#include "AnimationWindow.h"

class Dot{
    private:
        TDT4102::Point position;
        int radius;
        TDT4102::Color color = TDT4102::Color::red;
        AnimationWindow& win;
    public:
        Dot(TDT4102::Point position, int radius, AnimationWindow& win);
        void drawDot();
        int getPositionX(){return position.x;}
        int getPositionY(){return position.y;}
        void setPositionX(int x){position.x = x;}
        void setPositionY(int y){position.y = y;}
        void setColor(TDT4102::Color color){this->color = color;}
};