#include "std_lib_facilities.h"
#include "level.h"

Level::Level(int level, int gridWidth, int cellSize):
level{level}, 
gridWidth{gridWidth}, 
cellSize{cellSize}{

    uploadLevelTile();
}

Level::Level(const Level& lvl):
    level(lvl.level),
    cellSize(lvl.cellSize),
    gridWidth(lvl.gridWidth),
    startPoint(lvl.startPoint),
    endPoint(lvl.endPoint),
    grid(lvl.grid) {}

void Level::uploadLevelTile(){
    char ch, x, y; 
    vector<int> row;
    int temp;
    std::filesystem::path fileName{"levelGrids/level" + to_string(level) + ".txt"};
    std::ifstream inputStream{fileName};
    if (!inputStream) { // Sjekker om strømmen ble åpnet 
        std::cout << "Could not open file" << std::endl;
    }
    for (int i = 0; i < gridWidth; i++){
        for(int j = 0; j < gridWidth; j++){
            inputStream.get(ch);
            temp = ch;
            if (ch == ' ' || ch == '\n'){
                j--;
            }
            else{
                temp = static_cast<int>(ch - '0');
                row.push_back(temp);
            }
        }
        
        grid.push_back(row);
        row = {};
    }
    inputStream.get(ch)>>x>>y;
    TDT4102::Point start = {static_cast<int>(x - '0'),static_cast<int>(y - '0')};
    inputStream.get(ch)>>x>>y;
    TDT4102::Point end = {static_cast<int>(x - '0'),static_cast<int>(y - '0')};

    startPoint = {cellSize*(start.x)+int(cellSize/2), cellSize*(start.y)+int(cellSize/2)};
    endPoint = {cellSize*(end.x+1/2), cellSize*(end.y+1/2)};
    cout << "StartPunkt"<< startPoint.x << " " << startPoint.y << endl;

    inputStream.close();
}