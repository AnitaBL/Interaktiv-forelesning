#pragma once
#include "std_lib_facilities.h"
#include "AnimationWindow.h"
#include "level.h"
#include "dot.h"
#include "widgets/Button.h"

class Maze:public TDT4102::AnimationWindow{
    private:
        Level level;
        vector<Level> lvlVector;
        int cellSize = 50;
        int gridWidth = 10;
        int levelNumber;

        int dotRadius = 17;
        int bounds = cellSize*gridWidth;
        int xPosition = 0; int yPosition = 0;
        Dot dot;

        TDT4102::Color walls = TDT4102::Color::blue;
        TDT4102::Color path = TDT4102::Color::white;
        bool lightMode = true;


        void drawLevel(); 
        void moveRight(); void moveLeft(); void moveUp(); void moveDown();
        bool outOfBounds(TDT4102::Point point);
        void callbackFunction();

        string buttonLabel = "Light Mode";
        Button button;
        
    public:
    Maze(int levelNumber, int gridWidth, int cellSize);
    void gameWindow();
};